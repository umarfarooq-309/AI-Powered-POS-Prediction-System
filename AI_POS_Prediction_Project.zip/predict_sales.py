import pandas as pd
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import train_test_split

# Load sample data
data = pd.read_csv('data.csv')

# Convert Date to numerical value
data['Date'] = pd.to_datetime(data['Date'])
data['Day'] = data['Date'].dt.dayofyear

# Encode product types
data = pd.get_dummies(data, columns=['Product'], drop_first=True)

# Define features and target
X = data[['Day', 'Product_Soap']]
y = data['Units_Sold']

# Split data
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Train model
model = LinearRegression()
model.fit(X_train, y_train)

# Make predictions
predictions = model.predict(X_test)

# Display predictions
for i, pred in enumerate(predictions):
    print(f"Predicted units sold: {pred:.2f}, Actual units sold: {y_test.iloc[i]}")
